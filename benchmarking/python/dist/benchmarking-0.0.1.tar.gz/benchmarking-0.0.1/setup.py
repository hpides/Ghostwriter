# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['benchmarking', 'benchmarking.benchmarks', 'benchmarking.brokers']

package_data = \
{'': ['*']}

install_requires = \
['click>=8.1.3,<9.0.0', 'paramiko>=2.11.0,<3.0.0']

entry_points = \
{'console_scripts': ['ysb = benchmarks.ysb:main']}

setup_kwargs = {
    'name': 'benchmarking',
    'version': '0.0.1',
    'description': 'Tooling for benchmarking Ghostwriter',
    'long_description': None,
    'author': 'Hendrik Makait',
    'author_email': 'hendrik.makait@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
